const mantras = [
  {
    title: "দেবীর ধ্যানমন্ত্র",
    sanskrit: "ওঁ জটাজুটসমাযুক্তামর্ধেন্দুকৃতশেখরাম্।\nলোচনত্রয়সংযুক্তাং পদ্মেন্দুসদৃশাননাম্॥",
    bangla: "হে দেবী, আপনার জটাজুটে অর্ধচন্দ্র শোভিত, আপনার তিনটি চোখ এবং মুখমণ্ডল পদ্ম ও চন্দ্রের মতো।",
    usage: "পূজার শুরুতে ধ্যান করার সময়",
    color: "from-red-500 to-orange-500",
    emoji: "🕉️",
  },
  {
    title: "মহাষষ্ঠীর মন্ত্র",
    sanskrit: "ওঁ আগচ্ছ বরদে দেবি দৈত্যদর্পনিষূদনি।\nপূজাং গৃহাণ সুমুখি নমস্তে শঙ্করপ্রিয়ে॥",
    bangla: "হে বরদায়িনী দেবী! হে দৈত্যদলনকারিণী! হে সুমুখী! হে শংকরপ্রিয়ে! আমার পূজা গ্রহণ করুন।",
    usage: "মহাষষ্ঠীতে দেবীর আবাহনে",
    color: "from-pink-500 to-red-600",
    emoji: "🌸",
  },
  {
    title: "পুষ্পাঞ্জলির মন্ত্র",
    sanskrit: "ওঁ জয়ন্তী মঙ্গলা কালী ভদ্রকালী কপালিনী।\nদুর্গা শিবা ক্ষমা ধাত্রী স্বাহা স্বধা নমোস্তুতে॥",
    bangla: "হে জয়ন্তী, মঙ্গলা, কালী, ভদ্রকালী, কপালিনী, দুর্গা, শিবা, ক্ষমা, ধাত্রী — আপনাকে প্রণাম করি।",
    usage: "পুষ্পাঞ্জলি দেওয়ার সময়",
    color: "from-orange-500 to-yellow-500",
    emoji: "🌺",
  },
  {
    title: "মহাষ্টমীর মন্ত্র",
    sanskrit: "ওঁ সর্বমঙ্গলমঙ্গল্যে শিবে সর্বার্থসাধিকে।\nশরণ্যে ত্র্যম্বকে গৌরি নারায়ণি নমোস্তুতে॥",
    bangla: "হে সর্বমঙ্গলের মঙ্গলদায়িনী! হে শিবে! হে সর্বার্থ সাধিকা! হে ত্রিনয়নী গৌরী! আপনাকে প্রণাম।",
    usage: "অষ্টমী পূজায় ও যেকোনো সময়",
    color: "from-red-600 to-pink-600",
    emoji: "🙏",
  },
  {
    title: "দেবীস্তুতি (নমস্তস্যৈ)",
    sanskrit: "যা দেবী সর্বভূতেষু মাতৃরূপেণ সংস্থিতা।\nনমস্তস্যৈ নমস্তস্যৈ নমস্তস্যৈ নমো নমঃ॥",
    bangla: "যে দেবী সকল প্রাণীতে মাতৃরূপে অবস্থান করেন, তাঁকে নমস্কার, নমস্কার, নমস্কার।",
    usage: "সর্বসময়, বিশেষত সপ্তমী থেকে নবমীতে",
    color: "from-amber-500 to-orange-600",
    emoji: "✨",
  },
  {
    title: "বিসর্জনের মন্ত্র",
    sanskrit: "ওঁ গচ্ছ গচ্ছ পরং স্থানং স্বস্থানং পরমেশ্বরি।\nপূজোপচারাতিক্রান্তং ক্ষমস্ব পরমেশ্বরি॥",
    bangla: "হে পরমেশ্বরী! আপনি আপনার পরম স্থানে ফিরে যান। পূজায় কোনো ত্রুটি হলে ক্ষমা করুন।",
    usage: "দশমীতে দেবী বিসর্জনের সময়",
    color: "from-blue-500 to-indigo-600",
    emoji: "💧",
  },
];

export function MantraSection() {
  return (
    <section id="mantra" className="py-14 bg-gradient-to-b from-[#fdf6ec] to-orange-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 bg-orange-100 text-orange-700 rounded-full px-4 py-2 text-sm font-hind mb-4">
            🕉️ পূজার মন্ত্র সংগ্রহ
          </div>
          <h2 className="font-bengali text-3xl md:text-4xl font-bold text-red-800 mb-3">
            দুর্গাপূজার সম্পূর্ণ মন্ত্র
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-orange-500 to-red-600 mx-auto rounded-full mb-4"></div>
          <p className="text-gray-600 font-hind max-w-2xl mx-auto text-sm">
            পূজার প্রতিটি ধাপে ব্যবহৃত মূল মন্ত্রগুলো সংস্কৃত ও বাংলা অনুবাদসহ
          </p>
        </div>

        {/* Highlighted Shloka */}
        <div
          className="rounded-3xl p-8 md:p-12 text-center text-white mb-12 relative overflow-hidden"
          style={{ background: "linear-gradient(135deg, #7b1111 0%, #b71c1c 50%, #e65100 100%)" }}
        >
          <div className="absolute inset-0 opacity-5 pattern-bg"></div>
          <div className="relative z-10">
            <div className="text-5xl mb-4">🕉️</div>
            <h3 className="font-bengali text-2xl font-bold text-yellow-200 mb-4">মহামন্ত্র</h3>
            <p className="font-bengali text-lg md:text-2xl text-white leading-relaxed mb-4">
              "সর্বমঙ্গলমঙ্গল্যে শিবে সর্বার্থসাধিকে।<br />
              শরণ্যে ত্র্যম্বকে গৌরি নারায়ণি নমোস্তুতে॥"
            </p>
            <p className="font-hind text-sm text-orange-200">
              এই মন্ত্র প্রতিদিন সকালে ১০৮ বার জপ করলে মায়ের আশীর্বাদ লাভ হয়
            </p>
          </div>
        </div>

        {/* Mantra Cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {mantras.map((mantra, i) => (
            <div key={i} className="card-hover bg-white rounded-2xl shadow-md border border-orange-100 overflow-hidden">
              {/* Card Header */}
              <div className={`bg-gradient-to-r ${mantra.color} p-4 flex items-center gap-3`}>
                <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center text-xl">
                  {mantra.emoji}
                </div>
                <h3 className="font-bengali text-base font-bold text-white leading-snug">{mantra.title}</h3>
              </div>

              {/* Sanskrit */}
              <div className="bg-amber-50 border-b border-orange-100 p-4">
                <p className="text-xs text-amber-700 font-hind font-bold mb-1">📜 মূল সংস্কৃত:</p>
                <p className="font-bengali text-sm text-gray-800 leading-relaxed whitespace-pre-line">
                  {mantra.sanskrit}
                </p>
              </div>

              {/* Bengali Meaning */}
              <div className="p-4">
                <p className="text-xs text-orange-600 font-hind font-bold mb-1">🔤 বাংলা অর্থ:</p>
                <p className="font-hind text-sm text-gray-600 leading-relaxed mb-3">{mantra.bangla}</p>
                <div className="bg-orange-50 rounded-xl px-3 py-2 flex items-start gap-2">
                  <span className="text-orange-500 text-xs mt-0.5">⏰</span>
                  <p className="text-xs text-orange-700 font-hind">{mantra.usage}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-8">
          <button className="bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white font-bold px-8 py-3 rounded-full font-hind shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all">
            📖 সম্পূর্ণ মন্ত্র সংগ্রহ দেখুন
          </button>
        </div>
      </div>
    </section>
  );
}
